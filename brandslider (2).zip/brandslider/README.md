# Brand Slider - PrestaShop Module

A beautiful, responsive category slider module for PrestaShop 8.0+ and PrestaShop 9.0+

## Features

- ✅ Display selected categories as a sliding carousel
- ✅ Configurable number of visible items (2-8)
- ✅ Autoplay with adjustable speed
- ✅ Navigation arrows (show/hide)
- ✅ Dots pagination (show/hide)
- ✅ Fully responsive design
- ✅ Touch/swipe support for mobile
- ✅ Display on homepage and/or above footer
- ✅ Modern, premium styling with hover effects
- ✅ Child theme override support

## Installation

1. Upload the `brandslider.zip` file via **Back Office > Modules > Module Manager > Upload a module**
2. Or extract the `brandslider` folder to `/modules/` directory on your PrestaShop site
3. Go to **Back Office > Modules > Module Manager**
4. Search for "Brand Slider" and click **Install**
5. Configure the module settings

## Configuration Options

| Option | Description |
|--------|-------------|
| Categories to Display | Select which categories to show |
| Slider Title | Title displayed above the slider |
| Show Title | Toggle title visibility |
| Items Visible at Once | Number of categories visible (2-8) |
| Slide Transition Speed | Animation speed in milliseconds |
| Enable Autoplay | Auto-slide functionality |
| Autoplay Interval | Time between auto-slides |
| Show Navigation Arrows | Previous/Next buttons |
| Show Dots Pagination | Dot navigation |
| Display on Homepage | Enable homepage display |
| Display Above Footer | Enable footer display (all pages) |

## File Structure

```
brandslider/
├── brandslider.php              # Main module file
├── config.xml                   # Module configuration
├── composer.json                # Composer configuration
├── README.md                    # This file
└── views/
    ├── css/
    │   └── brandslider.css      # Slider styles
    ├── js/
    │   └── brandslider.js       # Carousel JavaScript
    └── templates/
        └── hook/
            └── displayHome.tpl  # Frontend template
```

## Requirements

- PrestaShop 8.0.0 or higher (tested on PrestaShop 9.0)
- PHP 8.1 or higher

## License

MIT License

